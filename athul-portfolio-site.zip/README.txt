ATHUL SANTHOSH PORTFOLIO - HOSTING GUIDE

Files
  index.html          the whole website (open it in a browser to preview)
  works/<category>/   put your videos and images here
  assets/             put your photo here (e.g. assets/athul.jpg)

Host it (any one of these, all free)
  1. Netlify Drop: go to app.netlify.com/drop and drag this whole folder in.
  2. Cloudflare Pages: Create project > Upload assets > upload this folder.
  3. GitHub Pages: upload the folder to a repo, Settings > Pages > deploy from main.
  Keep index.html and the works/ and assets/ folders together, with the same folder names.

Add your photo
  Copy the photo to assets/athul.jpg, then in index.html set:
  const PHOTO_SRC = "assets/athul.jpg";

Add a work (search for "const WORKS" in index.html)
  Image:  { title:"Name", tag:"Client", type:"image", src:"works/creatives/post-01.jpg" }
  Video:  { title:"Name", tag:"Client", type:"video", src:"works/motion/clip-01.mp4", poster:"works/motion/clip-01.jpg" }
  Keep each video under about 10 MB (720p, H.264 MP4) so the site loads fast.
  Videos listed with dv("Title", "driveFileId") open on Google Drive in a new tab.
  Replace them with the video format above to make them play on the page.
